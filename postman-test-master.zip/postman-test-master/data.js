const users = [
  {
    _id: 1587912698986,
    email: 'steve@home.org',
    password: '$2b$13$CW3SP.VCKI0NQFgu9plKQeXc3KugDB9hD/EB.nDgS79FQyxzBSDBW',
  },
];

const movies = [
  {
    _id: 'wfxt3zfri9n91cc3lrxdiav2cjutf4',
    title: 'Alien',
    year: 1979,
    owner: 1587912698986,
  },
];

module.exports = { users, movies };
